#######################################################################
SAP Leonardo Machine Learning foundation Cloud Foundry CLI Plugin V1.00
#######################################################################

Release Notes:
--------------

* Customer facing delivery via https://tools.hana.ondemand.com/#cloud
* Commands for Bring Your Own Model (BYOM)
* Commands for Retrainable Functional Services (Image & text)
* Support for MLf v2 APIs
* Shortcut aliases for all commands
* CLI version comman


Prerequisites:
--------------

- Cloud Foundry CLI v6.7.0 or higher

Instructions:
-------------

* Linux/Mac:

cf install-plugin -f sapmlcli

* Windows:

cf install-plugin -f sapmlcli.exe